import numpy as np
from DataSetting import *
from Regressor import * 
from HelpFunctions import *

from sklearn.linear_model import LinearRegression, TheilSenRegressor, RANSACRegressor, HuberRegressor
from sklearn.linear_model import RidgeCV, LassoCV, BayesianRidge
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor

# meta variables
random_state = 123

## SET PARAMETERS
# KNN Regressor
params_knn = [{'n_neighbors': 3*i} for i in range(1, 6)]

# Params Decistion Tree
max_depth_temp = [(i+1)*3 for i in range(5)]
max_leaf_nodes_temp = [None] + [(i+1)*3 for i in range(4)]
params_dt = [{'max_depth':i, 'max_leaf_nodes':j} for i in max_depth_temp for j in max_leaf_nodes_temp]

models = []


## ADD MMODELS
# add linear models
models += [Regressor("OLS", LinearRegression, [{}])]
models += [Regressor("ThSen", TheilSenRegressor, [{'random_state':random_state}])]
models += [Regressor("Ransac", RANSACRegressor, [{'random_state':random_state}])]
models += [Regressor("Huber", HuberRegressor, [{}])]

# ridge and lasso
models += [Regressor("Ridge", RidgeCV, [{}])]
models += [Regressor("Lasso", LassoCV, [{}])]

# Bayesian Ridge
models += [Regressor("BayRidge", BayesianRidge, [{}])]

# KNN Regressor
models += [Regressor("KNN", KNeighborsRegressor, params_knn)]

# add tree
models += [Regressor("DecTree", DecisionTreeRegressor, params_dt)]

# forest
models += [Regressor("Forest", RandomForestRegressor, [{}])]


## TEST IF WORKS
# create sample data
from sklearn.datasets import make_regression
dat_test = make_regression(1000, 15)
x_train, xtest = dat_test[0][:800], dat_test[0][800:]
y_train, ytest = dat_test[1][:800], dat_test[1][800:]

# create datasetting object
ds = DataSetting(y=dat_test[1], x=dat_test[0], models=models, loss_function=rmse)

# fit all models
ds.evaluate_all()

# output results
ds.collect_losses()