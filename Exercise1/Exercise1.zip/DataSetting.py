import numpy as np
from time import time

class DataSetting:
    def __init__(self, y, x, models, loss_function):
        self.y = y
        self.x = x
        self.models = models
        self.loss_function = loss_function
        
        for mod in self.models:
            mod.loss_function = self.loss_function
        
    def generate_cv(self, k):
        return(0)
    
    def evaluate_all(self):
        x_train, xtest = self.x, self.x[:100]
        y_train, ytest = self.y, self.y[:100]
        for mod in self.models:
            begin = time()
            mod.fit_all(x=x_train, y=y_train, x_test=xtest, y_test=ytest)
            print(mod.name, "done in", np.round(time() - begin, 3), "seconds.")
        print("\n")
            
    def collect_losses(self):
        for mod in self.models:
            for i in range(len(mod.parameters)):
                print(mod.name, "\t", np.round(mod.losses[i], 3), "\t", mod.parameters[i])